.. _pydicom_user_guide:

==================
Pydicom User Guide
==================

.. toctree::

   transition_to_pydicom1.rst
   base_element.rst
   writing_files.rst
   working_with_pixel_data.rst
   image_data_handlers.rst
   viewing_images.rst